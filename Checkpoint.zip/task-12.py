#  DEFINE DATA STRUCTURES TO REPRESENT CONTEXT. (9L) 
class type1 :
    def __init__(self,list1):
        self.list1 = list1
class type2:
    def __init__(self,list2):
      self.list2 = list2
class type3:
    def __init__(self,list3):
      self.list3 = list3