# DEFINE DATA STRUCTURES TO REPRESENT J0 PROGRAMS.(11L) 
class number:
   def __init__(self,a):
      self.a = a
class mult:
   def __init__(self, b, c):
      self.b = b
      self.c = c   
class add:
   def __init__(self, d, e):
        self.d = d
        self.e = e 